INSTRUCTIONS.
1. Open 2 images using the buttons at bottom left and select number of layers if desired.
2. Select Source ROI with either Rectangle, ellipse or freehand. Use DrawROI to start drawing. 
3. Select source and target location using the provided buttons to feed the location of the source and target on the newly shown images.
4. Press Blend!